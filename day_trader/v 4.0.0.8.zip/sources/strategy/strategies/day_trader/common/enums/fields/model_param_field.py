from enum import Enum
class ModelParamField(Enum):
    Symbol = 1
    Key = 2
    IntValue = 3
    FloatValue = 4
    StringValue = 5