class WebSocketMessage:
    def __init__(self, Msg):
        self.Msg = Msg
