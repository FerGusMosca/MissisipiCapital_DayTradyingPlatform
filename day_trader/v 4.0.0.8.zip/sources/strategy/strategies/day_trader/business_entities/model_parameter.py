class ModelParameter():

    def __init__(self, key=None, symbol = None,stringValue=None,intValue=None,floatValue = None):
        self.Key=key
        self.Symbol = symbol
        self.StringValue=stringValue
        self.IntValue = intValue
        self.FloatValue=floatValue

