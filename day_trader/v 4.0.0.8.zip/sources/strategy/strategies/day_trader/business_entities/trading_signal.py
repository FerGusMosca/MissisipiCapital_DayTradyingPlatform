class TradingSignal():

    def __init__(self, security=None,signal=None, recommendation = None):
        self.Security=security
        self.Signal= signal
        self.Recommendation = recommendation