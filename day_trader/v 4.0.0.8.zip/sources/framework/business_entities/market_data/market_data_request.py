from sources.framework.common.enums.SubscriptionRequestType import *
class MarketDataRequest:
    def __init__(self):

        self.Security = None
        self.SubscriptionRequestType = None

