from enum import Enum
class UpdateAction(Enum):
    New = 0
    Change = 1
    Delete = 2
