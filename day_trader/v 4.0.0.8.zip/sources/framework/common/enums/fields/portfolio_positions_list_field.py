from enum import Enum
class PortfolioPositionListFields(Enum):
    PortfolioPositions=1
    Status=2
    Error=3
