from enum import Enum
class CandleBarField(Enum):
    Time=1
    DateTime=2
    High=3
    Close=4
    Low=5
    NumberOfTicks=6
    Value=7
    Volume=8
    Open=9,
    Security = 10

