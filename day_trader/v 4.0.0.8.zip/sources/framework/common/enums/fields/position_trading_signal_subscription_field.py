from enum import Enum
class PositionTradingSignalSubscriptionField(Enum):
    PositionId=1
    Subscribe=2

