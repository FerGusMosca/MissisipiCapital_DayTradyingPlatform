from enum import Enum
class SummaryListFields(Enum):
    Summaries=1
    PositionId=2
    Status=3
    Error= 4
