from enum import Enum


class HistoricalPricesField(Enum):
    Security = 1
    TimeUnit = 2
    MarketDataArray = 3

